package com.desafiolatam.crud;

public interface Crud {

}
