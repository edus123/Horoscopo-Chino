package com.desafiolatam.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.desafiolatam.crud.Crud;
import com.desafiolatam.modelo.HoroscopoDTO;

import com.desafiolatam.procesaconexion.Conexion;

public class HoroscopoDAO implements Crud{
	

	
	public boolean create(HoroscopoDTO dto) {
		
		Connection cnn;
		PreparedStatement stmt;
		try {
			cnn = Conexion.generarEntregarConexion().getConexion();
			stmt = cnn.prepareStatement("String SQL");
			
			stmt.setInt(1, dto.getIdHoroscopo());
			stmt.setString(2, dto.getNombre());
			stmt.setString(3, dto.getDescripcion());
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		
		
		
		
	}
	
	String stmt = "SELECT FECHADENACIMIENTO FROM USUARIO WHERE NOMBRE =" 
	
}