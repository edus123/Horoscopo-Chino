package com.desafiolatam.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import siteweb1.Facade;
import siteweb1.HoroscopoDTO;

/**
 * Servlet implementation class PreConsulta
 */
@WebServlet("/PreConsulta")
public class PreConsulta extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PreConsulta() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		Facade facade = new Facade();
		int anio = null;
		String animal = "";
		HoroscopoDTO dto = new HoroscopoDTO();
		try {
		
		//llama al m�todo consultar hor�scopo de facade y este a su vez llama al metodo consultarHoroscopo de la clase HoroscopoDAO que realiza el query: SELECT ANIO_NACIMIENTO FROM TABLE WHERE NOMBRE = misesion.getAttribute("usuario",usuario), o en su defecto una variable usuario que posea el valor, algo similar a lo que hay en la pag 30
		 anio = facade.consultarAnio();
	     animal = facade.consultarAnimal();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		request.setAttribute("animal", animal);
		PrintWriter out = response.getWriter();
				
		
		RequestDispatcher reenviador =
				request.getRequestDispatcher("/consultaHoroscopo.jsp");
				reenviador.forward(request, response);
		
		

	
	}

}
